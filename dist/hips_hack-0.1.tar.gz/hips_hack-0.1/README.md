![banner](https://github.com/Skumbl/hips-hack/blob/main/Screenshot%202023-02-04%20at%2020-19-31%20Modern%20Minimal%20Technology%20Background%20Banner.png)
# H.I.P.S-HACK
## (HIDDEN IN PLAIN SIGHT)
[![Downloads](https://github.com/Skumbl/hips-hack)](https://github.com/Skumbl/hips-hack)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/python/black)
a python package that encrypts data as a string into an image

## Features
* pip3 package install
* easy command line use
* hide data inside of images
* data is randomly scattered and hidden bit by bit inside of pixels
* method of hiding passwords and verification keys
