# recreating the repository for pypy
# python3.11 setup.py sdist

# initial upload as new package
# twine upload dist/*

# upload as new version
# twine upload --skip-existing dist/*


# python3.11 setup.py sdist && twine upload --skip-existing dist/*